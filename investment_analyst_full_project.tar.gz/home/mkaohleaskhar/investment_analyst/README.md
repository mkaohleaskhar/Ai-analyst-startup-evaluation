# AI Startup Investment Analyst

This project is an AI-powered tool to analyze startup investment opportunities. It ingests startup materials, processes them through a series of AI agents, and generates a detailed investment analysis.
